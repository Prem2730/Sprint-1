package com.cg.mts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaseStudyMovieBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
