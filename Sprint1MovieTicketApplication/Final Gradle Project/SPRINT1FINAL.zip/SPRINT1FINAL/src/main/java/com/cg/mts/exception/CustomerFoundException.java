package com.cg.mts.exception;

public class CustomerFoundException extends Exception{
	public CustomerFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
}
}
