package com.cg.mts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaseStudyMovieBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaseStudyMovieBookingApplication.class, args);
		System.out.println("Started & its Connected");
	}

}
