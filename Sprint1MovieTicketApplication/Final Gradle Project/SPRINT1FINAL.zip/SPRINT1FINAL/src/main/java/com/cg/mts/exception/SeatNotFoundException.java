package com.cg.mts.exception;

public class SeatNotFoundException extends Exception {
	public SeatNotFoundException(String message) {
		super(message);
	}
}
