package com.cg.mts.exception;

public class ShowExistsException extends Exception {
	public ShowExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
