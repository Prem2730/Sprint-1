package com.cg.mts.exception;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
