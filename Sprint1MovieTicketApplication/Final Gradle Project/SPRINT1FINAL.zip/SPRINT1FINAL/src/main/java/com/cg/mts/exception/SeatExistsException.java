package com.cg.mts.exception;

public class SeatExistsException extends RuntimeException {
	public SeatExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
