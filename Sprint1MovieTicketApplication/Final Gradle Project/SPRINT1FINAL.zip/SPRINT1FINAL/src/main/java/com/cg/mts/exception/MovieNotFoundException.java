package com.cg.mts.exception;

public class MovieNotFoundException extends Exception {

	
	private static final long serialVersionUID = -7879333311664853554L;

	public MovieNotFoundException(String message) {
			super(message);
		}
	
}
