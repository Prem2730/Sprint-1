package com.cg.mts.exception;


public class BookingNotFoundException extends Exception {
	public BookingNotFoundException(String message) {
		super(message);
	}
}
