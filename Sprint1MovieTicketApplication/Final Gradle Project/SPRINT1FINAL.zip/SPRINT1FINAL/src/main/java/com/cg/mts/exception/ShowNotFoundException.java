package com.cg.mts.exception;

public class ShowNotFoundException extends Exception {
	public ShowNotFoundException(String message) {
		super(message);
	}
}
