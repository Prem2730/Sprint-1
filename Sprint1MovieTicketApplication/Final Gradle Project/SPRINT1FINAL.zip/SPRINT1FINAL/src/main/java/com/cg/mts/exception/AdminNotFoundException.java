package com.cg.mts.exception;

public class AdminNotFoundException extends RuntimeException{
	public AdminNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
