package com.cg.mts.service;

import com.cg.mts.entities.Ticket;

public interface ITicketService {
	public Ticket addTicket(Ticket ticket);
}
