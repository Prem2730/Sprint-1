package com.cg.mts.exception;

public class BookingNotDoneException extends Exception {
public BookingNotDoneException (String message) {
	super(message);
}
}




