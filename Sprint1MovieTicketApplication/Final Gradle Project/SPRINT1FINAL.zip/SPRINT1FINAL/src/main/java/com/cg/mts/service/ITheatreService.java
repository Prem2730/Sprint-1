package com.cg.mts.service;

import java.util.List;


import com.cg.mts.entities.Theatre;

public interface ITheatreService {

		public Theatre addTheatre(Theatre theatre);
		public List<Theatre> viewTheatreList();
		
		
	}

