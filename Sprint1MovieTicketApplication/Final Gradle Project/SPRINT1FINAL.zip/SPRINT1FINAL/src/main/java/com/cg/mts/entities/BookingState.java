package com.cg.mts.entities;

public enum BookingState {
	Available,Booked,Blocked;
}
