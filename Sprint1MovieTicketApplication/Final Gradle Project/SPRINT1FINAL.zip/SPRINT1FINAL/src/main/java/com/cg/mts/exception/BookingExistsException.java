package com.cg.mts.exception;

public class BookingExistsException extends RuntimeException {
	public BookingExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
